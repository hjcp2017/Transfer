# lx16a

> THIS IS WIP!

Python library to control the Hiwonder LX-16a digital serial servo motor.